import React, { useState, useEffect, useCallback } from 'react';
import { auth, db, signIn, logOut } from './firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { Desktop } from './components/Desktop';
import { WindowState, AppId } from './types';
import { motion, AnimatePresence } from 'motion/react';
import { LogIn, Monitor } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [windows, setWindows] = useState<WindowState[]>([]);
  const [activeWindowId, setActiveWindowId] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setUser(user);
      setLoading(false);
      if (user) {
        // Update user profile in Firestore
        await setDoc(doc(db, 'users', user.uid), {
          uid: user.uid,
          displayName: user.displayName,
          photoURL: user.photoURL,
          email: user.email,
          lastSeen: serverTimestamp(),
        }, { merge: true });
      }
    });
    return unsubscribe;
  }, []);

  const openApp = useCallback((appId: AppId, title: string, props?: any) => {
    const existingWindow = windows.find(w => w.appId === appId);
    if (existingWindow) {
      setActiveWindowId(existingWindow.id);
      setWindows(prev => prev.map(w => w.id === existingWindow.id ? { ...w, isMinimized: false, props: props || w.props } : w));
      return;
    }

    const newWindow: WindowState = {
      id: Math.random().toString(36).substr(2, 9),
      appId,
      title,
      isMinimized: false,
      isMaximized: false,
      zIndex: windows.length + 1,
      x: 100 + windows.length * 30,
      y: 100 + windows.length * 30,
      width: 800,
      height: 600,
      props,
    };

    setWindows(prev => [...prev, newWindow]);
    setActiveWindowId(newWindow.id);
  }, [windows]);

  const closeWindow = (id: string) => {
    setWindows(prev => prev.filter(w => w.id !== id));
    if (activeWindowId === id) setActiveWindowId(null);
  };

  const focusWindow = (id: string) => {
    setActiveWindowId(id);
    setWindows(prev => {
      const maxZ = Math.max(0, ...prev.map(w => w.zIndex));
      return prev.map(w => w.id === id ? { ...w, zIndex: maxZ + 1, isMinimized: false } : w);
    });
  };

  const toggleMinimize = (id: string) => {
    setWindows(prev => prev.map(w => w.id === id ? { ...w, isMinimized: !w.isMinimized } : w));
  };

  const toggleMaximize = (id: string) => {
    setWindows(prev => prev.map(w => w.id === id ? { ...w, isMaximized: !w.isMaximized } : w));
  };

  if (loading) {
    return (
      <div className="h-screen w-screen bg-neutral-950 flex items-center justify-center text-white font-mono">
        <motion.div
          animate={{ opacity: [0.4, 1, 0.4] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="flex flex-col items-center gap-4"
        >
          <Monitor className="w-12 h-12 text-emerald-500" />
          <div className="text-xl tracking-widest">GLINUX_LIVEOS BOOTING...</div>
        </motion.div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="h-screen w-screen bg-[#0a0a0a] flex items-center justify-center relative overflow-hidden">
        {/* Background Atmosphere */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-emerald-500/10 blur-[120px] rounded-full" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-500/10 blur-[120px] rounded-full" />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="z-10 bg-white/5 backdrop-blur-xl border border-white/10 p-12 rounded-3xl shadow-2xl flex flex-col items-center gap-8 max-w-md w-full"
        >
          <div className="w-20 h-20 bg-emerald-500/20 rounded-2xl flex items-center justify-center border border-emerald-500/30">
            <Monitor className="w-10 h-10 text-emerald-400" />
          </div>
          <div className="text-center">
            <h1 className="text-3xl font-bold text-white mb-2 tracking-tight">Glinux liveOS</h1>
            <p className="text-neutral-400 text-sm">A secure, collaborative environment for the modern web.</p>
          </div>
          <button
            onClick={signIn}
            className="w-full bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold py-4 px-6 rounded-xl transition-all flex items-center justify-center gap-3 group"
          >
            <LogIn className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            Sign in with Google
          </button>
          <div className="text-[10px] text-neutral-600 uppercase tracking-[0.2em] font-mono">
            v1.0.4-stable // kernel_5.15.0
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="h-screen w-screen overflow-hidden bg-[#1a1a1a] font-sans selection:bg-emerald-500/30">
      <Desktop
        user={user}
        windows={windows}
        activeWindowId={activeWindowId}
        openApp={openApp}
        closeWindow={closeWindow}
        focusWindow={focusWindow}
        toggleMinimize={toggleMinimize}
        toggleMaximize={toggleMaximize}
        onLogout={logOut}
      />
    </div>
  );
}
