import React, { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import { WindowState, AppId } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { Monitor, FileText, Folder, Settings, Search, Clock } from 'lucide-react';
import { cn } from '../lib/utils';

interface TaskbarProps {
  user: User;
  windows: WindowState[];
  activeWindowId: string | null;
  onAppClick: (id: string) => void;
  openApp: (appId: AppId, title: string) => void;
}

export const Taskbar: React.FC<TaskbarProps> = ({
  user,
  windows,
  activeWindowId,
  onAppClick,
  openApp,
}) => {
  const [isStartOpen, setIsStartOpen] = useState(false);
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="absolute bottom-3 left-1/2 -translate-x-1/2 h-14 bg-glass backdrop-blur-2xl border border-glass-border rounded-[20px] flex items-center px-4 gap-3 z-[9999] shadow-[0_10px_30px_rgba(0,0,0,0.5)]">
      {/* Start Button */}
      <button
        onClick={() => setIsStartOpen(!isStartOpen)}
        className={cn(
          "w-10 h-10 rounded-lg flex items-center justify-center transition-all",
          isStartOpen ? "bg-accent-primary text-white shadow-[0_0_15px_rgba(79,70,229,0.4)]" : "hover:bg-white/5 text-text-muted hover:text-text-main"
        )}
      >
        <Monitor className="w-5 h-5" />
      </button>

      <div className="w-[1px] h-6 bg-glass-border mx-1" />

      {/* Open Apps */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
        {windows.map((window) => (
          <button
            key={window.id}
            onClick={() => onAppClick(window.id)}
            className={cn(
              "h-10 px-4 rounded-lg flex items-center gap-3 transition-all min-w-[120px] max-w-[200px] border",
              activeWindowId === window.id 
                ? "bg-accent-primary border-white/20 text-white shadow-[0_0_15px_rgba(79,70,229,0.4)]" 
                : "bg-white/5 border-transparent hover:bg-white/10 text-text-muted hover:text-text-main"
            )}
          >
            <AppIcon appId={window.appId} className="w-4 h-4" />
            <span className="text-[12px] font-medium truncate">{window.title}</span>
          </button>
        ))}
      </div>

      <div className="w-[1px] h-6 bg-glass-border mx-1" />

      {/* System Tray */}
      <div className="flex items-center gap-4 pl-2">
        <div className="flex flex-col items-end min-w-[60px]">
          <span className="text-[11px] font-bold text-text-main">
            {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
          <span className="text-[9px] text-text-muted font-medium uppercase tracking-wider">
            {time.toLocaleDateString([], { month: 'short', day: 'numeric' })}
          </span>
        </div>
        <div className="w-8 h-8 rounded-full overflow-hidden border border-glass-border">
          <img src={user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.uid}`} alt="User" referrerPolicy="no-referrer" />
        </div>
      </div>

      {/* Start Menu */}
      <AnimatePresence>
        {isStartOpen && (
          <StartMenu 
            user={user} 
            onClose={() => setIsStartOpen(false)} 
            openApp={openApp}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

const AppIcon: React.FC<{ appId: AppId; className?: string }> = ({ appId, className }) => {
  switch (appId) {
    case 'writer': return <FileText className={className} />;
    case 'files': return <Folder className={className} />;
    case 'settings': return <Settings className={className} />;
    default: return <Monitor className={className} />;
  }
};

const StartMenu: React.FC<{ user: User; onClose: () => void; openApp: (appId: AppId, title: string) => void }> = ({ user, onClose, openApp }) => (
  <motion.div
    initial={{ opacity: 0, y: 20, scale: 0.95 }}
    animate={{ opacity: 1, y: 0, scale: 1 }}
    exit={{ opacity: 0, y: 20, scale: 0.95 }}
    className="absolute bottom-14 left-2 w-80 bg-[#1a1a1a]/95 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col"
  >
    {/* User Profile */}
    <div className="p-6 bg-white/5 border-b border-white/5 flex items-center gap-4">
      <img 
        src={user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.uid}`} 
        className="w-12 h-12 rounded-xl border border-white/10" 
        alt="User"
        referrerPolicy="no-referrer"
      />
      <div>
        <div className="text-sm font-bold text-white">{user.displayName}</div>
        <div className="text-[10px] text-emerald-400 font-mono uppercase tracking-wider">System Administrator</div>
      </div>
    </div>

    {/* Search */}
    <div className="p-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
        <input 
          type="text" 
          placeholder="Search apps and files..." 
          className="w-full bg-white/5 border border-white/5 rounded-lg py-2 pl-10 pr-4 text-xs text-white focus:outline-none focus:border-emerald-500/50 transition-colors"
        />
      </div>
    </div>

    {/* App Grid */}
    <div className="p-4 grid grid-cols-3 gap-2">
      <StartMenuItem 
        icon={<FileText className="w-6 h-6 text-emerald-400" />} 
        label="Writer" 
        onClick={() => { openApp('writer', 'Writer'); onClose(); }}
      />
      <StartMenuItem 
        icon={<Folder className="w-6 h-6 text-blue-400" />} 
        label="Files" 
        onClick={() => { openApp('files', 'Files'); onClose(); }}
      />
      <StartMenuItem 
        icon={<Settings className="w-6 h-6 text-neutral-400" />} 
        label="Settings" 
        onClick={() => { openApp('settings', 'Settings'); onClose(); }}
      />
      <StartMenuItem 
        icon={<Monitor className="w-6 h-6 text-emerald-500" />} 
        label="Terminal" 
        onClick={() => { openApp('terminal', 'Terminal'); onClose(); }}
      />
    </div>

    {/* Footer */}
    <div className="mt-auto p-4 bg-white/5 border-t border-white/5 flex justify-between items-center">
      <div className="text-[10px] text-white/40 font-mono">KERNEL_5.15.0-STABLE</div>
      <button className="text-[10px] text-white/60 hover:text-white transition-colors uppercase tracking-widest font-bold">Power Off</button>
    </div>
  </motion.div>
);

const StartMenuItem: React.FC<{ icon: React.ReactNode; label: string; onClick: () => void }> = ({ icon, label, onClick }) => (
  <button
    onClick={onClick}
    className="flex flex-col items-center gap-2 p-3 rounded-xl hover:bg-white/5 transition-colors group"
  >
    <div className="w-10 h-10 flex items-center justify-center bg-white/5 rounded-lg group-hover:bg-white/10 transition-colors">
      {icon}
    </div>
    <span className="text-[10px] text-white/60 font-medium">{label}</span>
  </button>
);
