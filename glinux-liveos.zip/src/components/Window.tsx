import React from 'react';
import { motion } from 'motion/react';
import { WindowState } from '../types';
import { X, Minus, Square, Maximize2 } from 'lucide-react';
import { cn } from '../lib/utils';

interface WindowProps {
  window: WindowState;
  isActive: boolean;
  onClose: () => void;
  onFocus: () => void;
  onMinimize: () => void;
  onMaximize: () => void;
  children: React.ReactNode;
}

export const Window: React.FC<WindowProps> = ({
  window,
  isActive,
  onClose,
  onFocus,
  onMinimize,
  onMaximize,
  children,
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95, y: 20 }}
      animate={{
        opacity: 1,
        scale: 1,
        y: 0,
        zIndex: window.zIndex,
        ...(window.isMaximized ? {
          top: 0,
          left: 0,
          width: '100%',
          height: 'calc(100% - 48px)',
        } : {
          top: window.y,
          left: window.x,
          width: window.width,
          height: window.height,
        })
      }}
      exit={{ opacity: 0, scale: 0.95, y: 20 }}
      drag={!window.isMaximized}
      dragMomentum={false}
      onPointerDown={onFocus}
      className={cn(
        "absolute flex flex-col bg-glass backdrop-blur-3xl border border-glass-border shadow-2xl overflow-hidden",
        window.isMaximized ? "rounded-none" : "rounded-xl",
        isActive ? "ring-1 ring-indigo-500/50" : ""
      )}
    >
      {/* Title Bar */}
      <div
        className="h-10 bg-white/5 backdrop-blur-md flex items-center justify-between px-4 cursor-default select-none border-b border-glass-border"
        onDoubleClick={onMaximize}
      >
        <div className="flex items-center gap-3">
          <div className="flex gap-2">
            <button
              onClick={(e) => { e.stopPropagation(); onClose(); }}
              className="w-3 h-3 rounded-full bg-red-500/80 hover:bg-red-500 transition-colors flex items-center justify-center group"
            >
              <X className="w-2 h-2 text-red-900 opacity-0 group-hover:opacity-100" />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); onMinimize(); }}
              className="w-3 h-3 rounded-full bg-slate-600 hover:bg-slate-500 transition-colors flex items-center justify-center group"
            >
              <Minus className="w-2 h-2 text-slate-900 opacity-0 group-hover:opacity-100" />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); onMaximize(); }}
              className="w-3 h-3 rounded-full bg-slate-600 hover:bg-slate-500 transition-colors flex items-center justify-center group"
            >
              <Maximize2 className="w-2 h-2 text-slate-900 opacity-0 group-hover:opacity-100" />
            </button>
          </div>
          <span className={cn(
            "text-[12px] font-medium tracking-wide",
            isActive ? "text-text-main" : "text-text-muted"
          )}>
            {window.title}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto bg-transparent">
        {children}
      </div>
    </motion.div>
  );
};
