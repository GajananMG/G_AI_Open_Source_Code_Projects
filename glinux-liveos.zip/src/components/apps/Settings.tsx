import React from 'react';
import { User } from 'firebase/auth';
import { LogOut, User as UserIcon, Shield, Palette, Info, Cpu } from 'lucide-react';

interface SettingsProps {
  user: User;
  onLogout: () => void;
}

export const Settings: React.FC<SettingsProps> = ({ user, onLogout }) => {
  return (
    <div className="h-full flex flex-col bg-transparent">
      <div className="p-8 border-b border-glass-border">
        <h2 className="text-2xl font-bold text-text-main tracking-tight">Settings</h2>
        <p className="text-text-muted text-sm mt-1">Manage your system preferences and profile.</p>
      </div>

      <div className="flex-1 overflow-auto p-8 flex flex-col gap-8">
        {/* Profile Section */}
        <section>
          <div className="flex items-center gap-2 text-xs font-bold text-text-muted uppercase tracking-widest mb-4">
            <UserIcon className="w-3 h-3" />
            User Profile
          </div>
          <div className="bg-white/5 border border-glass-border rounded-2xl p-6 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <img 
                src={user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.uid}`} 
                className="w-16 h-16 rounded-2xl border border-glass-border" 
                alt="User"
                referrerPolicy="no-referrer"
              />
              <div>
                <div className="text-lg font-bold text-text-main">{user.displayName}</div>
                <div className="text-sm text-text-muted">{user.email}</div>
              </div>
            </div>
            <button
              onClick={onLogout}
              className="bg-red-500/10 hover:bg-red-500/20 text-red-400 font-bold py-2 px-4 rounded-xl text-xs transition-all flex items-center gap-2 border border-red-500/20"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </button>
          </div>
        </section>

        {/* System Info */}
        <section>
          <div className="flex items-center gap-2 text-xs font-bold text-text-muted uppercase tracking-widest mb-4">
            <Cpu className="w-3 h-3" />
            System Information
          </div>
          <div className="grid grid-cols-2 gap-4">
            <InfoCard label="OS Name" value="Glinux liveOS" />
            <InfoCard label="Kernel Version" value="5.15.0-stable" />
            <InfoCard label="Architecture" value="x86_64 (Browser Emulated)" />
            <InfoCard label="Uptime" value="0d 0h 42m" />
          </div>
        </section>

        {/* Appearance */}
        <section>
          <div className="flex items-center gap-2 text-xs font-bold text-text-muted uppercase tracking-widest mb-4">
            <Palette className="w-3 h-3" />
            Appearance
          </div>
          <div className="bg-white/5 border border-glass-border rounded-2xl p-4 flex flex-col gap-2">
            <div className="flex items-center justify-between p-2">
              <span className="text-sm text-text-main/80">Dark Mode</span>
              <div className="w-10 h-5 bg-accent-primary rounded-full relative">
                <div className="absolute right-1 top-1 w-3 h-3 bg-white rounded-full" />
              </div>
            </div>
            <div className="flex items-center justify-between p-2 opacity-50">
              <span className="text-sm text-text-main/80">Glass Effects</span>
              <div className="w-10 h-5 bg-accent-primary rounded-full relative">
                <div className="absolute right-1 top-1 w-3 h-3 bg-white rounded-full" />
              </div>
            </div>
          </div>
        </section>
      </div>

      <div className="p-6 bg-white/5 border-t border-glass-border flex justify-center">
        <div className="text-[10px] text-text-muted font-mono tracking-widest uppercase">
          Built with Google AI Studio & Firebase
        </div>
      </div>
    </div>
  );
};

const InfoCard: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div className="bg-white/5 border border-glass-border rounded-xl p-4">
    <div className="text-[10px] text-text-muted font-bold uppercase tracking-wider mb-1">{label}</div>
    <div className="text-sm text-text-main font-mono">{value}</div>
  </div>
);
