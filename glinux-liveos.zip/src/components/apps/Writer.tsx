import React, { useState, useEffect, useRef } from 'react';
import { User } from 'firebase/auth';
import { db } from '../../firebase';
import { doc, onSnapshot, updateDoc, serverTimestamp, getDoc } from 'firebase/firestore';
import { DocData } from '../../types';
import { Users, Save, Share2, History, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface WriterProps {
  user: User;
  docId?: string;
}

export const Writer: React.FC<WriterProps> = ({ user, docId }) => {
  const [document, setDocument] = useState<DocData | null>(null);
  const [content, setContent] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const lastRemoteContent = useRef('');

  useEffect(() => {
    if (!docId) return;

    const unsubscribe = onSnapshot(doc(db, 'documents', docId), (snapshot) => {
      if (snapshot.exists()) {
        const data = { id: snapshot.id, ...snapshot.data() } as DocData;
        setDocument(data);
        
        // Only update local content if it differs from what we just received from remote
        // and we are not currently typing (to avoid cursor jumps)
        if (data.content !== content && data.content !== lastRemoteContent.current) {
          setContent(data.content);
          lastRemoteContent.current = data.content;
        }
      } else {
        setError('Document not found');
      }
    }, (err) => {
      console.error('Firestore Error:', err);
      setError('Permission denied or connection lost');
    });

    return unsubscribe;
  }, [docId]);

  const handleContentChange = async (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newContent = e.target.value;
    setContent(newContent);
    
    if (!docId) return;

    setIsSaving(true);
    try {
      await updateDoc(doc(db, 'documents', docId), {
        content: newContent,
        updatedAt: serverTimestamp(),
      });
      lastRemoteContent.current = newContent;
    } catch (err) {
      console.error('Save error:', err);
    } finally {
      setIsSaving(false);
    }
  };

  if (!docId) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-12 text-center gap-6">
        <div className="w-20 h-20 bg-emerald-500/10 rounded-3xl flex items-center justify-center border border-emerald-500/20">
          <FileText className="w-10 h-10 text-emerald-500" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-white mb-2">No Document Selected</h2>
          <p className="text-neutral-500 text-sm max-w-xs">Open a document from the Files app or create a new one to start collaborating.</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-12 text-center gap-4">
        <AlertCircle className="w-12 h-12 text-red-500" />
        <div className="text-white font-bold">{error}</div>
        <button onClick={() => window.location.reload()} className="text-emerald-500 text-sm hover:underline">Try reconnecting</button>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-transparent">
      {/* Toolbar */}
      <div className="h-12 border-b border-glass-border flex items-center justify-between px-4 bg-white/5">
        <div className="flex items-center gap-4">
          <h3 className="text-xs font-bold text-text-main uppercase tracking-widest">{document?.title || 'Loading...'}</h3>
          <div className="h-4 w-[1px] bg-glass-border" />
          <div className="flex items-center gap-1 text-[10px] text-text-muted font-mono">
            {isSaving ? (
              <motion.span animate={{ opacity: [0.4, 1, 0.4] }} transition={{ repeat: Infinity }}>SAVING...</motion.span>
            ) : (
              <span>SYNCED</span>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="p-2 hover:bg-white/5 rounded-lg text-text-muted transition-colors">
            <Users className="w-4 h-4" />
          </button>
          <button className="p-2 hover:bg-white/5 rounded-lg text-text-muted transition-colors">
            <Share2 className="w-4 h-4" />
          </button>
          <button className="p-2 hover:bg-white/5 rounded-lg text-text-muted transition-colors">
            <History className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Editor */}
      <div className="flex-1 p-8 overflow-auto">
        <textarea
          ref={textareaRef}
          value={content}
          onChange={handleContentChange}
          placeholder="Start typing your collaborative document..."
          className="w-full h-full bg-transparent text-text-main resize-none focus:outline-none font-mono text-sm leading-relaxed"
          spellCheck={false}
        />
      </div>

      {/* Footer */}
      <div className="h-8 border-t border-glass-border flex items-center justify-between px-4 bg-white/5 text-[10px] text-text-muted font-mono">
        <div>WORDS: {content.split(/\s+/).filter(Boolean).length}</div>
        <div className="flex items-center gap-4">
          <div>UTF-8</div>
          <div>LINUX (LF)</div>
        </div>
      </div>
    </div>
  );
};

import { FileText } from 'lucide-react';
