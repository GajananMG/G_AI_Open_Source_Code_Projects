import React, { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import { db } from '../../firebase';
import { collection, query, where, onSnapshot, addDoc, serverTimestamp, deleteDoc, doc } from 'firebase/firestore';
import { DocData, AppId } from '../../types';
import { FileText, Plus, Trash2, Clock, Search, MoreVertical } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface FilesProps {
  user: User;
  openApp: (appId: AppId, title: string, props?: any) => void;
}

export const Files: React.FC<FilesProps> = ({ user, openApp }) => {
  const [documents, setDocuments] = useState<DocData[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const q = query(
      collection(db, 'documents'),
      where('ownerId', '==', user.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as DocData));
      setDocuments(docs);
      setLoading(false);
    });

    return unsubscribe;
  }, [user.uid]);

  const createNewDoc = async () => {
    try {
      const docRef = await addDoc(collection(db, 'documents'), {
        title: 'Untitled Document',
        content: '',
        ownerId: user.uid,
        collaborators: [],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      openApp('writer', 'Writer', { docId: docRef.id });
    } catch (err) {
      console.error('Error creating document:', err);
    }
  };

  const deleteDocument = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Are you sure you want to delete this document?')) {
      try {
        await deleteDoc(doc(db, 'documents', id));
      } catch (err) {
        console.error('Error deleting document:', err);
      }
    }
  };

  const filteredDocs = documents.filter(d => 
    d.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="h-full flex flex-col bg-transparent">
      {/* Header */}
      <div className="p-6 border-b border-glass-border flex items-center justify-between bg-white/5">
        <div>
          <h2 className="text-xl font-bold text-text-main tracking-tight">Documents</h2>
          <p className="text-[10px] text-text-muted font-mono uppercase tracking-widest mt-1">/home/{user.displayName?.toLowerCase().replace(/\s+/g, '_')}/docs</p>
        </div>
        <button
          onClick={createNewDoc}
          className="bg-accent-primary hover:opacity-90 text-white font-bold py-2 px-4 rounded-lg flex items-center gap-2 text-xs transition-all shadow-lg shadow-accent-primary/20"
        >
          <Plus className="w-4 h-4" />
          New Document
        </button>
      </div>

      {/* Search */}
      <div className="px-6 py-4 border-b border-glass-border">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted/40" />
          <input
            type="text"
            placeholder="Search documents..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white/5 border border-glass-border rounded-lg py-2 pl-10 pr-4 text-xs text-text-main focus:outline-none focus:border-accent-primary/50 transition-colors"
          />
        </div>
      </div>

      {/* List */}
      <div className="flex-1 overflow-auto p-4">
        {loading ? (
          <div className="h-full flex items-center justify-center">
            <motion.div animate={{ rotate: 360 }} transition={{ duration: 2, repeat: Infinity, ease: "linear" }}>
              <Clock className="w-6 h-6 text-accent-primary/40" />
            </motion.div>
          </div>
        ) : filteredDocs.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-text-muted gap-4">
            <Folder className="w-12 h-12 opacity-20" />
            <p className="text-xs font-medium">No documents found</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-1">
            {filteredDocs.map((doc) => (
              <button
                key={doc.id}
                onClick={() => openApp('writer', 'Writer', { docId: doc.id })}
                className="group flex items-center justify-between p-3 rounded-xl hover:bg-white/5 transition-all text-left border border-transparent hover:border-glass-border"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-accent-primary/10 rounded-lg flex items-center justify-center group-hover:bg-accent-primary/20 transition-colors">
                    <FileText className="w-5 h-5 text-accent-primary" />
                  </div>
                  <div>
                    <div className="text-sm font-medium text-text-main group-hover:text-white transition-colors">{doc.title}</div>
                    <div className="text-[10px] text-text-muted font-mono mt-0.5">
                      MODIFIED: {doc.updatedAt?.toDate().toLocaleString() || 'Just now'}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button 
                    onClick={(e) => deleteDocument(doc.id, e)}
                    className="p-2 hover:bg-red-500/20 text-text-muted hover:text-red-400 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <button className="p-2 hover:bg-white/10 text-text-muted hover:text-text-main rounded-lg transition-colors">
                    <MoreVertical className="w-4 h-4" />
                  </button>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

import { Folder } from 'lucide-react';
