import React, { useState, useEffect, useRef } from 'react';
import { User } from 'firebase/auth';

export const Terminal: React.FC<{ user: User }> = ({ user }) => {
  const [lines, setLines] = useState<string[]>([
    'Glinux liveOS Kernel 5.15.0-stable (x86_64)',
    `Welcome back, ${user.displayName}.`,
    '',
    'Type "help" for a list of commands.',
  ]);
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [lines]);

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const cmd = input.trim().toLowerCase();
    const newLines = [...lines, `${user.displayName?.toLowerCase().replace(/\s+/g, '_')}@glinux:~$ ${input}`];

    switch (cmd) {
      case 'help':
        newLines.push('Available commands: help, clear, whoami, uname, date, ls, exit');
        break;
      case 'clear':
        setLines([]);
        setInput('');
        return;
      case 'whoami':
        newLines.push(user.displayName || 'unknown');
        break;
      case 'uname':
        newLines.push('Linux Glinux 5.15.0-stable #1 SMP PREEMPT x86_64 GNU/Linux');
        break;
      case 'date':
        newLines.push(new Date().toString());
        break;
      case 'ls':
        newLines.push('documents/  downloads/  pictures/  system/');
        break;
      case 'exit':
        newLines.push('Terminal session ended. Please close the window.');
        break;
      default:
        newLines.push(`bash: ${cmd}: command not found`);
    }

    setLines(newLines);
    setInput('');
  };

  return (
    <div className="h-full bg-black/40 p-4 font-mono text-xs leading-relaxed flex flex-col">
      <div ref={scrollRef} className="flex-1 overflow-auto no-scrollbar mb-2">
        {lines.map((line, i) => (
          <div key={i} className={line.startsWith(user.displayName?.toLowerCase().replace(/\s+/g, '_') || '') ? "text-indigo-400" : "text-text-main"}>
            {line}
          </div>
        ))}
      </div>
      <form onSubmit={handleCommand} className="flex gap-2">
        <span className="text-indigo-400">{user.displayName?.toLowerCase().replace(/\s+/g, '_')}@glinux:~$</span>
        <input
          autoFocus
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="flex-1 bg-transparent text-text-main focus:outline-none"
          spellCheck={false}
        />
      </form>
    </div>
  );
};
