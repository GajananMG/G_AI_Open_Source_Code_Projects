import React from 'react';
import { User } from 'firebase/auth';
import { WindowState, AppId } from '../types';
import { Window } from './Window';
import { Taskbar } from './Taskbar';
import { Writer } from './apps/Writer';
import { Files } from './apps/Files';
import { Settings } from './apps/Settings';
import { Terminal } from './apps/Terminal';
import { motion, AnimatePresence } from 'motion/react';
import { FileText, Folder, Settings as SettingsIcon, Terminal as TerminalIcon } from 'lucide-react';

interface DesktopProps {
  user: User;
  windows: WindowState[];
  activeWindowId: string | null;
  openApp: (appId: AppId, title: string, props?: any) => void;
  closeWindow: (id: string) => void;
  focusWindow: (id: string) => void;
  toggleMinimize: (id: string) => void;
  toggleMaximize: (id: string) => void;
  onLogout: () => void;
}

export const Desktop: React.FC<DesktopProps> = ({
  user,
  windows,
  activeWindowId,
  openApp,
  closeWindow,
  focusWindow,
  toggleMinimize,
  toggleMaximize,
  onLogout,
}) => {
  const [time, setTime] = React.useState(new Date());

  React.useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const renderApp = (window: WindowState) => {
    switch (window.appId) {
      case 'writer':
        return <Writer user={user} docId={window.props?.docId} />;
      case 'files':
        return <Files user={user} openApp={openApp} />;
      case 'settings':
        return <Settings user={user} onLogout={onLogout} />;
      case 'terminal':
        return <Terminal user={user} />;
      default:
        return <div className="p-8 text-neutral-500 font-mono">App not found: {window.appId}</div>;
    }
  };

  return (
    <div className="relative h-full w-full overflow-hidden bg-bg-base">
      {/* Wallpaper - Immersive Gradient */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_0%_0%,#1e1b4b_0%,transparent_50%),radial-gradient(circle_at_100%_100%,#312e81_0%,transparent_50%),radial-gradient(circle_at_50%_50%,#06070a_0%,#0f172a_100%)]" />
      </div>

      {/* System Status Bar */}
      <div className="absolute top-5 right-8 flex gap-5 text-[12px] text-text-muted font-medium z-0">
        <span>CPU 12%</span>
        <span>MEM 2.4GB</span>
        <span>WIFI: OS_Secure</span>
        <span>{time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
      </div>

      {/* Desktop Icons */}
      <div className="absolute top-8 left-8 flex flex-col gap-8">
        <DesktopIcon
          icon={<FileText className="w-8 h-8 text-indigo-400" />}
          label="Writer"
          onClick={() => openApp('writer', 'Writer')}
        />
        <DesktopIcon
          icon={<Folder className="w-8 h-8 text-blue-400" />}
          label="Files"
          onClick={() => openApp('files', 'Files')}
        />
        <DesktopIcon
          icon={<SettingsIcon className="w-8 h-8 text-slate-400" />}
          label="Settings"
          onClick={() => openApp('settings', 'Settings')}
        />
        <DesktopIcon
          icon={<TerminalIcon className="w-8 h-8 text-emerald-500" />}
          label="Terminal"
          onClick={() => openApp('terminal', 'Terminal')}
        />
      </div>

      {/* Windows */}
      <AnimatePresence>
        {windows.map((window) => (
          !window.isMinimized && (
            <Window
              key={window.id}
              window={window}
              isActive={activeWindowId === window.id}
              onClose={() => closeWindow(window.id)}
              onFocus={() => focusWindow(window.id)}
              onMinimize={() => toggleMinimize(window.id)}
              onMaximize={() => toggleMaximize(window.id)}
            >
              {renderApp(window)}
            </Window>
          )
        ))}
      </AnimatePresence>

      {/* Taskbar */}
      <Taskbar
        user={user}
        windows={windows}
        activeWindowId={activeWindowId}
        onAppClick={(id) => focusWindow(id)}
        openApp={openApp}
      />
    </div>
  );
};

const DesktopIcon: React.FC<{ icon: React.ReactNode; label: string; onClick: () => void }> = ({ icon, label, onClick }) => (
  <motion.button
    whileHover={{ scale: 1.05 }}
    whileTap={{ scale: 0.95 }}
    onClick={onClick}
    className="flex flex-col items-center gap-2 group w-20"
  >
    <div className="w-12 h-12 bg-white/5 backdrop-blur-md border border-white/5 rounded-xl flex items-center justify-center group-hover:bg-white/10 transition-colors shadow-lg">
      {React.cloneElement(icon as React.ReactElement, { className: 'w-6 h-6' })}
    </div>
    <span className="text-[11px] font-medium text-text-main/80 tracking-wide drop-shadow-md">{label}</span>
  </motion.button>
);
